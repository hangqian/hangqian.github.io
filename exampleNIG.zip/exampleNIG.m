% Example code for Bayesian linear regression by NIG summation

% Specification of two NIG distributions
d = 10;
mu1 = rand(d,1);
Lambda1 = 0.3*ones(d) + 0.7*eye(d);
a1 = 5;
b1 = 10;
mu2 = rand(d,1);
Lambda2 = 7*ones(d) + 3*eye(d);
a2 = 50;
b2 = 20;

% Zeros in NIG summation
NIG1 = NIG(mu1,Lambda1,a1,b1);
NIG0 = NIG(zeros(d,1),zeros(d),-d/2,0);
NIG10 = NIG1 + NIG0;

if compareNIG(NIG1,NIG10)
    disp('Validated: Zeros in NIG summation')
end

% Pseudo data extraction from NIG
NIG2 = NIG(mu2,Lambda2,a2,b2);
NIG12 = NIG1 + NIG2;
[X,y] = extract(NIG2);
EstNIG = estimate(NIG1,X,y);

if compareNIG(NIG12,EstNIG)
    disp('Validated: Pseudo data extraction from NIG')
end


%--------------------------------------------------------------------------
function TF = compareNIG(NIG1,NIG2)
tol = 1e-10;
if norm(NIG1.Mu-NIG2.Mu)<tol && norm(NIG1.Precision-NIG2.Precision)<tol && norm(NIG1.A-NIG2.A)<tol && norm(NIG1.B-NIG2.B)<tol 
    TF = true;
else
    TF = false;
end
end