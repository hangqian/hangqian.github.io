%APPCREDITSHOPPING Bayesian linear regression of mortgage rate
%
% Description:
% Bayesian linear regression and state-specific split-and-merge regression 
% by NIG summation, subtraction and scalar multiplication.
%
%
% Data source:
% HMDA mortgage dataset, year of 2021
% https://ffiec.cfpb.gov
%
% Data pre-processing: 
% Run DataProcess.m first for data pre-processing.

rng('default')

% Specification
numLenders = 100;

% Load mortgage data
if exist("Table43.mat","file") == 2
    load("Table43.mat","Table");
else
    % Load data
    fileName = 'D:\BigData\Mortgage\Data2021\Short2021.csv';
    Table = readtable(fileName);

    % Subsample: loan originated for single family home purchase, 
    %             with 10 - 30 years fixed interest rate
    nobsRaw = size(Table,1);
    condition = true(nobsRaw,10);
    condition(:,1) = Table.action_taken == 1;  % loan originated
    condition(:,2) = Table.dwelling == 1; % single Family (1-4 Units):Site-Built
    condition(:,3) = Table.loan_purpose == 1; % home purchase
    condition(:,4) = Table.loanType > 0; % First lien conventional, FHA or VA loan
    condition(:,5) = (Table.loan_term >= 120 & Table.loan_term <= 360) & ~(Table.intro_rate_period < Table.loan_term); % 10-30 years fixed interest rate mortgage

    % Remove error records and outliers
    condition(:,6) = Table.income > 0 & Table.income < 1e6;
    condition(:,7) = Table.loan_amount > 1e4 & Table.loan_amount < 1e7;
    condition(:,8) = Table.interest_rate > 1 & Table.interest_rate < 10;
    condition(:,9) = Table.rate_spread > -3 & Table.rate_spread < 10;
    condition(:,10) = Table.state > 0;
    Table = Table(all(condition,2),:);
    save("Table43.mat","Table");
end
nobs = size(Table,1);

% Split the sample into training and testing subsamples
training = rand(nobs,1) < 0.99;
testing = ~training;

% Extract regressors X and y from data table
TableTrain = Table(training,:);
[X,y,varNames,blacklist] = functionXY(TableTrain,numLenders);
numPredictors = size(X,2);

% Bayesian linear regression under the non-informative prior
Mdl = diffuseblm(numPredictors,'VarNames',varNames,'Intercept',0);
EstMdl = estimate(Mdl,X,y);

% Out of sample forecast
[XF,yFTrue] = functionXY(Table(testing,:),numLenders,blacklist);
yForecast = XF * EstMdl.Mu;
forecastError = yForecast - yFTrue;
RMSE = sqrt(mean(forecastError.^2,'omitnan'));
fprintf('Forecast RMSE = %4.3f\n',RMSE);

% Split and merge regressions
numStates = 50;
priorNIG = NIG(zeros(numPredictors,1),eye(numPredictors),3,1);
subposteriorNIG = cell(numStates,1);
posteriorNIG = NIG(zeros(numPredictors,1),zeros(numPredictors),-numPredictors/2,0);
for m = 1:numStates
    select = TableTrain.state == m;
    [XSubset,ySubset,varNames,blacklist] = functionXY(TableTrain(select,:),numLenders,blacklist);
    subposteriorNIG{m} = estimate(priorNIG,XSubset,ySubset,0);
    posteriorNIG = posteriorNIG + subposteriorNIG{m};
end
posteriorNIG = posteriorNIG - priorNIG * numStates;

% Write results to spreadsheet
AIO = zeros(numPredictors+1,7);
Summary = summarize(EstMdl);
AIO(:,1) = Summary.MarginalDistributions.Mean;
for m = 1:5
    [BetaMean,~,Sigma2Mean] = summary(subposteriorNIG{m});
    AIO(:,m+1) = [BetaMean;Sigma2Mean];    
end
[BetaMean,~,Sigma2Mean] = summary(posteriorNIG);
AIO(:,7) = [BetaMean;Sigma2Mean];
colNames = ["FullSample","AL","AK","AZ","AR","CA","Merged"];
rowNames = [varNames,"sigma2"];
selectRows = [1:27,73:82,173];
internal.econ.tableprint(AIO(selectRows,:),'RowNames',rowNames(selectRows),'ColNames',colNames,'NumDigits',4,'fileName','Results.xlsx');


%-------------------------------------------------------------------------
% In-script function: extract regression data from table
function [X,y,varNames,blacklist] = functionXY(Table,numLenders,blacklist)

if nargin < 2; numLenders = 100; end
if nargin < 3; blacklist = []; end

% Debt to income ratio (in percentage points)
debtIncomeRatio = Table.debtIncomeRatio;

% Loan to value ratio (in percentage points)
% loanValueRatio = Table.loan_to_value_ratio; 
loanValueRatio = Table.loan_amount ./ Table.property_value * 100;
loanValueRatio(loanValueRatio>100) = 100;
loanValueRatio(loanValueRatio<10) = NaN;

% Prevailing interest rate on the market (prime offer rate)
% In 2021, the market rate should be around 2.8%
% Rate spread data are available for some, but not all, mortgages.
% Also, it appears that some rate spread data are incorrect. For example,
% the implied market interest rate could be negative.
marketRate = Table.interest_rate - Table.rate_spread;
marketRate(isnan(marketRate) | marketRate < 1.5 | marketRate > 5) = 2.8;

% Loan size in logarithm, to capture the effects of jumbo loans
loanSize = log(Table.loan_amount) * 100;

% Approximated down payment
downPayment = log(max(1,Table.property_value - Table.loan_amount));

% Loan term in months for 10-30 years mortgage
loanTerm = Table.loan_term;

% Popular term: 15 or 30 years mortgage
popularTerm = Table.loan_term == 180 | Table.loan_term == 360;

% Discount points paid to reduce interest rate
% Converted to percentage of the loan amount
points = Table.discount_points ./ Table.loan_amount * 100;
points(isnan(points)) = 0;

% Origination charges, as the percentage of the loan amount
origination = Table.origination_charges ./ Table.loan_amount * 100;
origination(isnan(origination)) = 0;

% Non-primary residence for investments
% secondHome = Table.occupancy_type == 2;
investment = Table.occupancy_type == 3;

% Commercial purpose
commercial = Table.business_or_commercial_purpose == 1;

% Applicant income
% income = Table.income ./ Table.ffiec_msa_md_median_family_income * 100;
income = log(Table.income) * 100;

% Applicant age
age = Table.age;

% Applicant gender
female = Table.sex == 2;
joint = Table.sex == 3;

% Applicant race and ethnicity
asia = Table.race == 2;
africa = Table.race == 3;
hispanic = Table.ethnicity == 1;

% Loans insured by FHA or VA
FHA = Table.loanType == 2;
VA = Table.loanType == 3;
FSA = Table.loanType == 4;

% Rich or poor neighborhood where the property locates
% neighborhood = Table.tract_to_msa_income_percentage;
region = log(Table.ffiec_msa_md_median_family_income) * 100;

% State dummy
nobs = size(Table,1);
numStates = 50;
states = zeros(nobs,numStates);
for m = 1:numStates
    states(:,m) = Table.state == m;
end

% Major lenders dummy
% Lenders are ranked based on their total number of loans.
% However, some lenders specialize in a certain loan type. For example,
% 21ST MORTGAGE CORPORATION specializes in manufactured and mobile home 
% loans, but our subsample does not cover those loans. Therefore, they are
% excluded from dummy variables to prevent multi-colliearity.
% blacklist = [19 27 36 40 44 53 58 77 86 87 94 110 113 114 115 117 126 157 165 166 168 170 174 175 181 183 185 187 199 203 211 216 220];
lenders = zeros(nobs,numLenders);
if isempty(blacklist)
    blacklist = [];
    count = 0;
    for m = 1:numLenders*2
        select = Table.lender == m;
        if sum(select) > 1000
            count = count + 1;
            lenders(:,count) = select;
            if count >= numLenders
                break
            end
        else
            blacklist = [blacklist,m]; %#ok<AGROW>
        end
    end
else
    count = 0;
    for m = 1:numLenders*2
        select = Table.lender == m;
        if ~ismember(m,blacklist)
            count = count + 1;
            lenders(:,count) = select;
            if count >= numLenders
                break
            end        
        end
    end
end

%{
if ~isempty(blacklist)
    disp('Exclude some lenders to prevent multi-colliearity.')
    disp(blacklist)
end
%}

% Construct regression data
y = Table.interest_rate;
X = [debtIncomeRatio,loanValueRatio,marketRate,loanSize,downPayment,loanTerm,popularTerm,points,origination,investment,commercial,income,age,female,joint,asia,africa,hispanic,FHA,VA,FSA,region,states,lenders];

% Variable names
varNamesCore = ["debt/Income","loan/Value","marketRate","loanSize","downPayment","loanTerm","popularTerm","discountPoints","originationFee","investment","commercial","income","age","female","jointFilers","asian","african","hispanic","FHA","VA_","FSA","regionIncome"];
stateName = ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"];
varNames = [varNamesCore,stateName,"lender"+(1:numLenders)];

% Remove missing values
valid = isfinite(y) & all(isfinite(X(:,1:end-numStates-numLenders)),2);
X = X(valid,:);
y = y(valid,:);
end
