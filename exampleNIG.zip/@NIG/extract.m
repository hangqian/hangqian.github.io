function [X,y] = extract(Mdl,compactFlag)
%EXTRACT Extract pseudo-observations from normal-inverse-gamma distribution
%
% Syntax:
%
%   [X,y] = extract(Mdl,0)
%   DataStruct = extract(Mdl,1)
%
% Description:
%
%   Pseudo-observations X,y are extracted from a NIG distribution such that
%   the posterior distribution using X,y under the non-informative prior
%   recovers the original NIG distribution.
%
% Input Arguments:
%
%   Mdl -         Normal-inverse-gamma distribution
%
%   compactFlag - Logical indicator of data compression
%                 If compactFlag = 0, the outputs are two numeric matrices
%                    X is n-by-k pseudo predictor data
%                    y is n-by-1 pseudo response data
%                 If compactFlag = 1, the output is a struct with fields
%                    o X1: k-by-k dense pseudo predictor data
%                    o Y1: k-by-1 dense pseudo response data
%                    o X2: scalar value for all entries of (n-k)-by-k X2
%                    o Y2: scalar value for all entries of (n-k)-by-1 Y2
%                    o SampleSize: sample size n
%                 The default is false.
%
%
% Output Arguments:
%
%   X          -  n-by-k pseudo predictor data extracted from NIG
%
%   y          -  n-by-1 pseudo response data extracted from NIG
% 
%   DataStruct -  a struct array of compressed data with fields
%                   o X1: k-by-k dense pseudo predictor data
%                   o Y1: k-by-1 dense pseudo response data
%                   o X2: scalar value for all entries of (n-k)-by-k X2
%                   o Y2: scalar value for all entries of (n-k)-by-1 Y2
%                   o SampleSize: sample size n
%

if nargin < 2
    compactFlag = false;
end

% Load NIG parameters
Mu = Mdl.Mu;
Precision = Mdl.Precision;
A = Mdl.A;
B = Mdl.B;

% Dimension
nreg = length(Mu);
nobs = 2*A + nreg;

% First block of predictors: X1'*X1 = Precision
% X1 contains at most k rows. If Precision has reduced rank, X1 may contain
% less than k rows, but subject to numeric issues of rank determination
X1 = cholcov(Precision);
y1 = X1 * Mu;
nobs1 = size(X1,1);

% Second block of predictors
nobs2 = nobs - nobs1;
if B<=0 || nobs2<0 || (nobs2==0 && B>0)
    error('A and B must be large enough to recover observations.')
end
if nobs2~=round(nobs2)
    warning('Calibrated sample size is not an integer.')
    nobs2 = round(nobs2);
end
y2Scalar = sqrt(B/A);

% Extract pseudo observations
if compactFlag
    % Compress data in a struct
    X = struct('X1',X1,'Y1',y1,'X2',0,'Y2',y2Scalar,'SampleSize',nobs);
    y = [];
else
    % Concatenate extracted data
    X2 = zeros(nobs2,nreg);
    y2 = repmat(y2Scalar,nobs2,1);
    X = [X1;X2];
    y = [y1;y2];
end

