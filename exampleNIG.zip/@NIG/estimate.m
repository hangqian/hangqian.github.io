function PosteriorNIG = estimate(PriorNIG,X,y,intercept)
%ESTIMATE Posterior distribution of conjugate models
%
% Syntax:
%
%   PosteriorNIG = estimate(PriorNIG,X,y,intercept)
%   PosteriorNIG = estimate(PriorNIG,DataStruct)
%
% Description:
%
%   First, use X,y to obtain posterior NIG under the non-informative prior
%   Second, sum up the prior and posterior NIG distributions
%
% Input Arguments:
%
%   PriorNIG   - prior normal-inverse-gamma distribution
%
%   X          - n-by-k predictor data. 
%
%   y          - n-by-1 response data.
%
%   DataStruct - struct array of compressed pseudo observations, extracted
%                from a NIG distribution. DataStruct is returned by EXTRACT
%                method of the NIG class.
%
%   intercept  - logical indicator of adding a column of ones to the first
%                column of X. The default is false.
%
% 
% Output Arguments:
%
%   PosteriorNIG - posterior normal-inverse-gamma distribution
%
% Notes:
%
%  o If intercept = 0, then NIG dimension must equal to size(X,2).
%  o If intercept = 1, then NIG dimension must equal to 1 + size(X,2).
%  o Intercept cannot be added to pseudo observations.

if nargin < 2
    error('A NIG and observations must be supplied for Bayesian linear regression')
end

% Process input arguments
if isstruct(X)
    % Support syntax: estimate(PriorNIG,DataStruct)
    compactFlag = true;
    DataStruct = X;
    if nargin < 3
        intercept = false;
    else
        intercept = y;
    end
    X = [];
    y = [];    
else
    % Support syntax: estimate(PriorNIG,X,y,intercept)
    compactFlag = false;
    if nargin < 4
        intercept = false;
    end
    DataStruct = [];
end

validateattributes(intercept,{'numeric','logical'},{'scalar','binary'},'NIG.estimate');

if compactFlag && intercept
    error('Intercept is absorbed in pseudo observations, which do not have a column of ones.')
end

% Check dimensions
if ~isa(X,'tall')
    if compactFlag
        nreg = size(DataStruct.X1,2);
    else
        nreg = size(X,2);
    end
    switch length(PriorNIG.Mu)
        case nreg + intercept
            % Pass
        case nreg
            error('Intercept added to X. PriorMdl must contain priors for intercept.')
        otherwise
            error('Dimension inconsistency.')
    end    
end

% High-dimensional regression (n < k)
if ~isa(X,'tall') && ~compactFlag && size(X,1)<(nreg+intercept)
    nobs = numel(y);
    if intercept
        X = [ones(nobs,1),X];
    end    
    Precision = PriorNIG.Precision + X' * X;
    Mu = Precision \ (PriorNIG.Precision * PriorNIG.Mu + X' * y);
    A = PriorNIG.A + 0.5 * nobs;
    B = PriorNIG.B + 0.5 * (y.' * y + PriorNIG.Mu' * PriorNIG.Precision * PriorNIG.Mu - Mu' * Precision * Mu );
    PosteriorNIG = NIG(Mu,Precision,A,B,PriorNIG.VarNames);
    return
end

% Posterior distribution
if compactFlag
    % Posterior distribution under the non-informative prior
    [Mu,Precision,A,B]= NIG.noninformativeCompact(DataStruct);
    DataNIG = NIG(Mu,Precision,A,B,PriorNIG.VarNames);
    
    % Sum up the prior and posterior NIGs
    PosteriorNIG = PriorNIG + DataNIG;
elseif isa(X,'tall')
    % Posterior distribution under the non-informative prior
    [Mu,Precision,A,B]= noninformativeTall(X,y,intercept);
    DataNIG = NIG(Mu,Precision,A,B,PriorNIG.VarNames);
    
    % Sum up the prior and posterior NIGs
    PosteriorNIG = PriorNIG + DataNIG;
else
    % In case of multi-collinearity, DataNIG under non-informative prior
    % will be of reduced rank, so we compute conjugate posteriors directly
    % Instead of NIG summation
    
    % Data cleaning
    y = y(:);
    missing = isnan(y) | any(isnan(X),2);
    if any(missing)
        X = X(~missing,:);
        y = y(~missing);
    end
    
    % Add an intercept term
    nobs = size(X,1);
    if intercept
        X = [ones(nobs,1),X];        
    end
    
    % Sufficient statistics
    XX = X.' * X;
    XY = X.' * y;
    YY = y.' * y;
    
    % Posterior under the conjugate prior
    % PrecisionBar should be of full rank, even if XX is of reduced rank
    Mu = PriorNIG.Mu;
    Precision = PriorNIG.Precision;
    A = PriorNIG.A;
    B = PriorNIG.B;
    PrecisionBar = Precision + XX;
    MuBar = PrecisionBar \ (Precision * Mu + XY);
    ABar = A + nobs/2;
    BBar = B + 0.5 * (YY + Mu.' * Precision * Mu - MuBar.' * PrecisionBar * MuBar);
    PosteriorNIG = NIG(MuBar,PrecisionBar,ABar,BBar,PriorNIG.VarNames);
    
end



