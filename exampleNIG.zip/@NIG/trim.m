function SmallNIG = trim(BigNIG,indicator)
%TRIM Dimension reduction of NIG conditional on zero elements
%
% Syntax:
%
%   SmallNIG = trim(BigNIG,indicator)
%
% Description:
%
%   Assume that (Beta1,Beta2,Sigma2) is a NIG.
%   Then (Beta1,Sigma2)|Beta is a reduced-dimension NIG.
%
% Input Arguments:
%
%   BigNIG -    Normal-inverse-gamma distribution
%
%   indicator - k-by-1 logical vector in which the zero elements are the
%               conditioning variables. That is, Beta1 = Beta(indicator),
%               Beta2 = Beta(~indicator). The output NIG is a reduced
%               dimension NIG, conditional on Beta2 = 0.
%
% Output Arguments:
%
%   SmallNIG    Reduced dimension normal-inverse-gamma distribution
%

% Load NIG parameters
Mu = BigNIG.Mu;
Precision = BigNIG.Precision;
A = BigNIG.A;
B = BigNIG.B;
VarNames = BigNIG.VarNames;

if numel(Mu) ~= numel(indicator)
    error('NIG and indicator must have the same dimension')
end

% Partition parameters
indicator = logical(indicator(:));
Mu1 = Mu(indicator);
Mu0 = Mu(~indicator);
Precision11 = Precision(indicator,indicator);
Precision10 = Precision(indicator,~indicator);
Precision01 = Precision(~indicator,indicator);
Precision00 = Precision(~indicator,~indicator);

% Dimension reduction
ratio = Precision11 \ Precision10;
MuTrim = Mu1 + ratio * Mu0;
PrecisionTrim = Precision11;
ATrim = A + 0.5 * numel(Mu0);
BTrim = B + 0.5 * Mu0' * (Precision00 - Precision01*ratio) * Mu0;
VarNamesTrim = VarNames(indicator);

% Construct the reduced dimension NIG
SmallNIG = NIG(MuTrim,PrecisionTrim,ATrim,BTrim,VarNamesTrim);
