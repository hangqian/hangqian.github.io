function [BetaMean,BetaStd,Sigma2Mean,Sigma2Std,BetaCov] = summary(Mdl)
%SUMMARY Summary statistics of NIG distributions
%
% Syntax:
%
%   [BetaMean,BetaStd,Sigma2Mean,Sigma2Std] = summary(Mdl)
%
% Description:
%
%   Compute mean and standard deviations of NIG(Mu,Precision,A,B)
%
% Input Arguments:
%
%   Mdl -         Normal-inverse-gamma distribution
%
% Output Arguments:
%
%   BetaMean    - k-by-1 mean for Beta
%
%   BetaStd     - k-by-1 standard deviation for Beta
%
%   Sigma2Mean  - scalar mean for Sigma2
%
%   Sigma2Std   - scalar standard deviation for Sigma2
%
%   BetaCov     - k-by-k covariance matrix for Beta

% Load NIG parameters
Mu = Mdl.Mu;
Precision = Mdl.Precision;
A = Mdl.A;
B = Mdl.B;
nreg = numel(Mu);

% Recover variance from precision
mask0 = diag(Precision)==0;
V = zeros(nreg);
V(~mask0,~mask0) = inv(Precision(~mask0,~mask0));
V(mask0,mask0) = diag(Inf(sum(mask0),1));

% Marginal distribution of Beta is multivariate t
BetaMean = Mu;
V = V ./ (A/B);
df = 2 * A; 
if df > 2
    BetaCov = df./(df-2).*V;
else
    BetaCov = diag(NaN(nreg,1));
end
BetaStd = sqrt(diag(BetaCov));

% Marginal distribution of Sigma2 is inverse gamma
Sigma2Mean = B / (A-1);
Sigma2Var = B*B / ((A-1).*(A-1).*(A-2));
Sigma2Std = sqrt(Sigma2Var);
