function disp(Mdl)
% DISP Display summary statistics of NIG distributions
%
% Input Arguments:
%
%   Mdl -         Normal-inverse-gamma distribution


% Compute NIG summary statistics
[BetaMean,BetaStd,Sigma2Mean,Sigma2Std] = summary(Mdl);

% Table of summary statistics
AIO = [ [BetaMean;Sigma2Mean],[BetaStd;Sigma2Std] ];

% Display summary statistics on the screen
colNames = {'Mean','Std'};
rowNames = [Mdl.VarNames;{'Sigma2'}];
try
    internal.econ.tableprint(AIO,'ColNames',colNames,'RowNames',rowNames);
catch
    SummaryStat = array2table(AIO,'VariableNames',colNames,'RowNames',rowNames);
    disp(SummaryStat)
end

