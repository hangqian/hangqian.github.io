function NIGx = times(NIG1,x)
%TIMES Scalar multiplication of normal-inverse-gamma distributions
%
% Syntax:
%
%  NIGx = NIG1 * x, where x is a positive scalar
%
% Description:
%
%   Rescale normal-inverse-gamma distributions as if their embedded
%   regression data precision changes.
%
% Input Arguments:
%
%   NIG1 - Normal-inverse-gamma distribution
%
%   x - a positive scalar
%
% Output Arguments:
%
%   NIGx    Combined normal-inverse-gamma distribution
%

if ~isscalar(x)
    error('x must be a scalar.')
end

% Load NIG parameters
Mu1 = NIG1.Mu;
Precision1 = NIG1.Precision;
A1 = NIG1.A;
B1 = NIG1.B;
VarNames1 = NIG1.VarNames;
nreg1 = numel(Mu1);

% Rescale precision
Precision = Precision1 .* x;

% Mean remains the same
Mu = Mu1;

% Accumulate inverse gamma A
A = A1 * x + 0.5 * (x-1) * nreg1;

% Formulate inverse gamma B
B = B1 * x;

% Construct the combined NIG
NIGx = NIG(Mu,Precision,A,B,VarNames1);
