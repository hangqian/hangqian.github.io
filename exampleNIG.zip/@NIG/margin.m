function logPY = margin(PriorNIG,X,y,intercept)
%MARGIN Marginal log likelihood of NIG Bayesian linear regression
%
% Syntax:
%
%   logPY = margin(PriorNIG,X,y,intercept)
%   logPY = margin(PriorNIG,DataStruct)
%
% Description:
%
%   First, use X,y to obtain posterior NIG under the non-informative prior
%   Second, sum up the prior and posterior NIG models
%   Third, compute the density of NIG models
%   Fourth, obtain marginal likelihood by Bayes formula
%   p(Y) = p(Beta,Sigma2) * p(Y|Beta,Sigma2) / p(Beta,Sigma2|Y) 
%
% Input Arguments:
%
%   PriorNIG  - Prior normal-inverse-gamma distribution
%
%   X         - n-by-k predictor data. 
%
%   y         - n-by-1 response data. 
%
%   DataStruct - struct array of compressed pseudo observations, extracted
%                from a NIG distribution. DataStruct is returned by EXTRACT
%                method of the NIG class.
%
%   intercept - logical indicator of adding a column of ones to the first
%               column of X. The default is false.
%
% 
% Output Arguments:
%
%   logPY      - Marginal log likelihood for p(y)
%
% Notes:
%
%  o If intercept = 0, then NIG dimension must equal to size(X,2).
%  o If intercept = 1, then NIG dimension must equal to 1 + size(X,2).
%  o Intercept cannot be added to pseudo observations.

if nargin < 2
    error('A NIG and observations must be supplied for computing marginal likelihood')
end

% Process input arguments
if isstruct(X)
    % Support syntax: margin(PriorNIG,DataStruct)
    compactFlag = true;
    DataStruct = X;
    if nargin < 3
        intercept = false;
    else
        intercept = y;
    end
    X = [];
    y = [];    
else
    % Support syntax: margin(PriorNIG,X,y,intercept)
    compactFlag = false;
    if nargin < 4
        intercept = false;
    end
    DataStruct = [];
end

validateattributes(intercept,{'numeric','logical'},{'scalar','binary'},'NIG.margin');

if compactFlag && intercept
    error('Intercept is absorbed in pseudo observations, which do not have a column of ones.')
end

% Posterior distribution
if compactFlag
    PosteriorNIG = estimate(PriorNIG,DataStruct,intercept);
else
    PosteriorNIG = estimate(PriorNIG,X,y,intercept);
end

% Density of prior and posterior evaluated at Beta=0, Sigma2=100
Sigma2 = 100;
logPrior = density(PriorNIG,0,Sigma2);
logPosterior = density(PosteriorNIG,0,Sigma2);

% Log likelihood evaluated at Beta=0, Sigma2=100
if compactFlag
    y1 = DataStruct.Y1;
    y2 = DataStruct.Y2;
    nobs = DataStruct.SampleSize;
    nobs2 = nobs - numel(y1);
    RSS = y1' * y1 + nobs2 * y2^2;
    logL = -0.5 * (log(2*pi*Sigma2)*nobs + RSS/Sigma2);
else
    valid = all(~isnan([y,X]),2);
    nobs = sum(valid);
    RSS = sum(y(valid).^2);        
    logL = -0.5 * (log(2*pi*Sigma2)*nobs + RSS/Sigma2);
end

% Marginal likelihood from Bayes formula
% Usually both logL and logPosterior are large negative number
logPY = logPrior + (logL - logPosterior);

