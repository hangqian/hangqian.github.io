function [Beta,Sigma2] = simulate(Mdl,numDraws)
%SIMULATE Simulate Beta and Sigma2 draws from normal-inverse-gamma distribution
%
% Syntax:
%
%   [Beta,Sigma2] = simulate(Mdl,numDraws)
%
% Description:
%
%   (Beta,Sigma2) ~ NIG(Mu,Precision,A,B).
%   That is, Beta|Sigma2 ~ N(Mu,Sigma2*inv(Precision)), Sigma2 ~ IG(A,B).
%
% Input Arguments:
%
%   Mdl -   Normal-inverse-gamma distribution
%
%
% Output Arguments:
%
%   Beta    k-by-NumDraws Beta draws
%
%   Sigma2  1-by-NumDraws Sigma2 draws

if nargin < 2
    numDraws = 1;
end

% Load NIG parameters
Mu = Mdl.Mu;
Precision = Mdl.Precision;
A = Mdl.A;
B = Mdl.B;
nreg = length(Mu);

if any(diag(Precision)==0)
    error('Improper normal distribution cannot be simulated.')
end

if A <= 0 || B <= 0
    error('Improper inverse gamma distribution cannot be simulated.')
end

% Simulate Sigma2 from IG(a,b)
Sigma2 = 1 ./ gamrnd(A, 1/B, 1, numDraws);

% Simulate Beta|Sigma2 from normal distribution
[PrecisionChol,cholFlag] = chol(Precision);
if cholFlag > 0
    PrecisionChol = chol(Precision + (1e-10) * eye(nreg));
end
% Implicit expansion on + and .*
Beta = Mu + sqrt(Sigma2) .* (PrecisionChol \ randn(nreg,numDraws));

