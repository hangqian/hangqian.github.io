function logPDF = density(Mdl,Beta,Sigma2)
%DENSITY Log density of normal-inverse-gamma distribution
%
% Syntax:
%
%   logPDF = density(Mdl,Beta,Sigma2)
%
% Description:
%
%   (Beta,Sigma2) ~ NIG(Mu,Precision,A,B).
%   That is, Beta|Sigma2 ~ N(Mu,Sigma2*inv(Precision)), Sigma2 ~ IG(A,B).
%
% Input Arguments:
%
%   Mdl -       Normal-inverse-gamma distribution
%
%   Beta -      k-by-1 evaluation point for Beta
%
%   Sigma2 -    Scalar evaluation point for Sigma2 
%
% Output Arguments:
%
%   logPDF     Log density of NIG evaluated at (Beta,Sigma2)
%

% Load NIG parameters
Mu = Mdl.Mu;
Precision = Mdl.Precision;
A = Mdl.A;
B = Mdl.B;

Beta = Beta(:);
if ~isscalar(Beta) && (numel(Mu) ~= numel(Beta))
    error('NIG and Beta must have the same dimension')
end

if any(diag(Precision)==0)
    error('Density of improper normal distribution cannot be evaluated')
end

if A <= 0 || B <= 0
    error('Density of improper inverse gamma distribution cannot be evaluated')
end

% Density of IG(a,b)
logPdfSigma2 = -gammaln(A) + A*log(B) - (A+1)*log(Sigma2) - B/Sigma2;

% Density of N(Mu,Sigma2*inv(Precision))
dim = numel(Mu);
constant = -0.5*dim*log(2*pi);
PrecChol = chol(Precision);
detTerm = sum(log(diag(PrecChol))) - 0.5*dim*log(Sigma2);
point = PrecChol * (Beta-Mu);
expTerm = -0.5*(point' * point) / Sigma2;
logPdfBeta = constant + detTerm + expTerm;

% Density of NIG(mu,Precision,a,b)
logPDF = logPdfSigma2 + logPdfBeta;

