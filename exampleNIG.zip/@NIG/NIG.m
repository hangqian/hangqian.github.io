classdef NIG
%NIG: Normal-inverse-gamma conjugate distribution
%
% Syntax:
%
%   Mdl = NIG(Mu,Precision,A,B)
%   Mdl = NIG(Mu,Precision,A,B,VarNames)
%
% Description:
%
%   Conjugate Bayesian linear regression:
%
%   Y(i) = X(i) * Beta + Sigma * e(i), 
%
%   where e(i) ~ iid N(0,1), (Beta,Sigma2) ~ NIG(Mu,Precision,A,B). 
%   That is, Beta|Sigma2 ~ N(Mu,Sigma2*inv(Precision)), Sigma2 ~ IG(A,B).
%
%
% Input Arguments:
%
%   Mu        - k-by-1 mean vector
%   Precision - k-by-k precision matrix
%   A         - scalar inverse gamma shape parameter
%   B         - scalar inverse gamma scale parameter
%   VarNames  - k-by-1 cell array of variable names
%
% Output Argument:
%
%   Mdl      - NIG object with the properties Mu, Precision, A, B, VarNames


    properties      
        Mu
        Precision
        A
        B
        VarNames
    end
    
    methods        
        function Mdl = NIG(Mu,Precision,A,B,VarNames)
            
            if isscalar(Mu)
                Mu = Mu * ones(size(Precision,1),1);
            elseif any(numel(Mu) ~= size(Precision))
                error('Dimension inconsistency.')
            end
                        
            Mdl.Mu = Mu(:);
            Mdl.Precision = Precision;
            Mdl.A = A;
            Mdl.B = B;
            
            if nargin < 5
                nreg = numel(Mu);
                VarNames = cell(nreg,1);
                for m = 1:nreg
                    VarNames{m} = sprintf('Beta(%d)',m);
                end
            end
            Mdl.VarNames = VarNames(:);            
            
        end
    end
    
    
    methods (Static)
        
        function [Mu,Precision,A,B,nobs] = noninformative(X,y,intercept)
        % NONINFORMATIVE: Bayesian linear regression under noninformative prior
        %
        % Input Arguments
        %
        % X           - n-by-k predictor data
        % y           - n-by-1 response data
        % intercept   - logical indicator of adding a column of ones to the
        %               first column of X
        %
        % Output Arguments
        %
        %   Mu        - k-by-1 posterior mean vector
        %   Precision - k-by-k posterior precision matrix
        %   A         - scalar posterior inverse gamma shape parameter
        %   B         - scalar posterior inverse gamma scale parameter
        %   nobs      - scalar sample size
        
        
            if isa(X,'tall')
                % Tall array version by MapReduce
                [Mu,Precision,A,B,nobs] = noninformativeTall(X,y,intercept);
            else
                % Regular version of Bayesian linear regression
                
                % Data cleaning                
                y = y(:);
                missing = isnan(y) | any(isnan(X),2);
                if any(missing)
                    X = X(~missing,:);
                    y = y(~missing);
                end
                
                % Add an intercept term
                [nobs,nreg] = size(X);
                if intercept
                    X = [ones(nobs,1),X];
                    nreg = nreg + intercept;
                end
                                
                % Sufficient statistics
                % Note: MATLAB rejects matrix multiplication for logical array
                if ~islogical(X)
                    XX = X.' * X;
                    XY = X.' * y;
                else
                    XX = zeros(nreg,nreg);
                    XY = zeros(nreg,1);
                    for m = 1:nreg 
                        Xmask = X(:,m);
                        XX(m,m) = sum(Xmask);
                        XY(m) = sum(y(Xmask));
                        for n = m+1:nreg
                            XX(m,n) = sum(Xmask & X(:,n));
                            XX(n,m) = XX(m,n);
                        end
                    end
                end                
                YY = y.' * y;                
                
                % Posterior under the non-informative prior
                Mu = XX \ XY;
                Precision = XX;
                A = 0.5 * (nobs - nreg);
                B = 0.5 * (YY - Mu' * Precision * Mu); 
            end
            
        end
        
        %-----------------------------------------------------------------
        function [Mu,Precision,A,B,nobs] = noninformativeCompact(DataStruct)
            
        % NONINFORMATIVECOMPACT: Bayesian linear regression under noninformative prior
        %
        % Input Arguments
        %
        % DataStruct  - struct array of compressed pseudo observations, extracted
        %               from a NIG distribution. DataStruct is returned by EXTRACT
        %               method of the NIG class.
        %
        % Output Arguments
        %
        %   Mu        - k-by-1 posterior mean vector
        %   Precision - k-by-k posterior precision matrix
        %   A         - scalar posterior inverse gamma shape parameter
        %   B         - scalar posterior inverse gamma scale parameter
        %   nobs      - scalar sample size
        %
        % Note:
        %
        % o Intercept term (a column of ones) should be absorbed in the
        %   pseudo observations, which do not have a column of ones.
            
            % Load data
            X1 = DataStruct.X1;
            y1 = DataStruct.Y1;
            y2 = DataStruct.Y2;
            nobs = DataStruct.SampleSize;
            [nobs1,nreg] = size(X1);
            nobs2 = nobs - nobs1; 
                                    
            % Sufficient statistics
            XX = X1.' * X1;
            XY = X1.' * y1;
            YY = y1.' * y1 + nobs2 * y2^2;
            
            % Posterior under the non-informative prior
            Mu = XX \ XY;
            Precision = XX;
            A = 0.5 * (nobs - nreg);
            B = 0.5 * (YY - Mu' * Precision * Mu);
            
        end
        
        %-------------------------------------------------------------------------
        function [PriorNIG,logPM] = getPrior(subset,Mu,Precision,A,B,priorProb,PrecisionData,strength,CustomPrior,VarNames)
            %GETPRIOR Get prior NIG for a subset of predictors
            %
            % Input Arguments:
            %
            % subset: logical vector that indicates variable selection
            % Mu,Precision,A,B: prior NIG for all possible predictors (saturated model)
            % priorProb: prior variable inclusion probability
            % PrecisionData: X'*X for constructing g-prior
            % strength: adjustment to baseline g-prior (X'*X)/k^2
            % CustomPrior: function handle that overloads Mu,Precision,A,B,priorProb
            % VarNames: variable names
            %
            % Output Arguments:
            %
            % PriorNIG: prior NIG for a subset of predictors
            % logPM: log prior model probability log(P(M))
            
            if isempty(CustomPrior)
                MuCut = Mu(subset,1);
                if isempty(Precision)
                    PrecisionCut = strength .* PrecisionData(subset,subset) / max(1,length(Mu)^2);
                else
                    PrecisionCut = strength .* Precision(subset,subset);
                end
                PriorNIG = NIG(MuCut,PrecisionCut,A,B,VarNames);
                logPM = sum(log(priorProb(subset))) + sum(log(1-priorProb(~subset)));
            else
                [MuCut,PrecisionCut,A,B,PriorProbNew] = CustomePrior(subset);
                PriorNIG = NIG(MuCut,PrecisionCut,A,B,VarNames);
                logPM = log(PriorProbNew);
            end
        end
        
        %-----------------------------------------------------------------
        % Log likelihood of linear regression models
        % This is just a signature of the static method
        % Call this function by NIG.likelihood(...)
        logL = likelihood(Beta,Sigma2,X,y,intercept)
    end
end