function NIGx = mtimes(NIG1,x)
%MTIMES Scalar multiplication of normal-inverse-gamma distributions
%
% Syntax:
%
%  NIGx = NIG1 .* x, where x is a positive scalar
%
% Description:
%
%   Rescale normal-inverse-gamma distributions as if their embedded
%   regression data precision changes.
%
% Input Arguments:
%
%   NIG1 - Normal-inverse-gamma distribution
%
%   x - a positive scalar
%
% Output Arguments:
%
%   NIGx    Combined normal-inverse-gamma distribution
%

NIGx = times(NIG1,x);