function NIG12 = plus(NIG1,NIG2)
%PLUS Summation of two normal-inverse-gamma distributions
%
% Syntax:
%
%  NIG12 = NIG1 + NIG2
%
% Description:
%
%   Combine normal-inverse-gamma distributions as if their embedded
%   regression data are concatenated.
%
% Input Arguments:
%
%   NIG1 - Normal-inverse-gamma distribution
%
%   NIG2 - Normal-inverse-gamma distribution
%
% Output Arguments:
%
%   NIG12    Combined normal-inverse-gamma distribution
%

% Load NIG parameters
Mu1 = NIG1.Mu;
Mu2 = NIG2.Mu;
Precision1 = NIG1.Precision;
Precision2 = NIG2.Precision;
A1 = NIG1.A;
A2 = NIG2.A;
B1 = NIG1.B;
B2 = NIG2.B;
VarNames1 = NIG1.VarNames;
VarNames2 = NIG2.VarNames;

nreg1 = numel(Mu1);
nreg2 = numel(Mu2);
if nreg1 ~= nreg2
    error('Two NIG distributions must have the same dimension.')
end

% Combined precision
Precision = Precision1 + Precision2;

% Weighted average of information
Mu = Precision \ (Precision1 * Mu1 + Precision2 * Mu2);

% Accumulate inverse gamma A
A = A1 + A2 + 0.5 * nreg1;

% Formulate inverse gamma B
% Alternative formula:
% B = B1 + B2 + 0.5 * (Mu1-Mu2)' * inv(inv(Precision1)+inv(Precision2)) * (Mu1-Mu2)
gap1 = (Mu1- Mu)' * Precision1 * (Mu1- Mu);
gap2 = (Mu2- Mu)' * Precision2 * (Mu2- Mu);
B = B1 + B2 + 0.5 * (gap1 + gap2);

% Construct the combined NIG
if nreg1 > 0 && strcmp(VarNames1{1},'Beta(1)') && ~strcmp(VarNames2{1},'Beta(1)')
    VarNames = VarNames2;
else
    VarNames = VarNames1;
end
NIG12 = NIG(Mu,Precision,A,B,VarNames);
