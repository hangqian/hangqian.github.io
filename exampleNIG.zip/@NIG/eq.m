function tf = eq(NIG1,NIG2)
%EQ Determine equality of two normal-inverse-gamma distributions
%
% Syntax:
%
%  NIG1 == NIG2
%
% Description:
%
%   Two normal-inverse-gamma distributions are equal if all properties of 
%   Mu, Precision, A and B are equal.
%
% Input Arguments:
%
%   NIG1 - Normal-inverse-gamma distribution
%
%   NIG2 - Normal-inverse-gamma distribution
%
% Output Arguments:
%
%   tf    logical 1 (true) if they are equivalent, 0 (false) otherwise.
%

tf = isequal(NIG1,NIG2);
