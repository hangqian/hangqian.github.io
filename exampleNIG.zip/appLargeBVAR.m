clear
clc

% An Application on Large Bayesian Vector Autoregression
% Data source:
% Federal Reserve Economic Data (FRED) database
% https://fred.stlouisfed.org
folder = 'FredData';

% Output, income and expenditure data
GDPC1 = readtimetable(fullfile(folder,"GDPC1.xls"),"NumHeaderLines",10);         % Real Gross Domestic Product
PCECC96 = readtimetable(fullfile(folder,"PCECC96.xls"),"NumHeaderLines",10);     % Real Personal Consumption Expenditures
GPDIC1 = readtimetable(fullfile(folder,"GPDIC1.xls"),"NumHeaderLines",10);       % Real Gross Private Domestic Investment
GCEC1 = readtimetable(fullfile(folder,"GCEC1.xls"),"NumHeaderLines",10);         % Real Government Consumption Expenditures and Gross Investment
EXPGSC1 = readtimetable(fullfile(folder,"EXPGSC1.xls"),"NumHeaderLines",10);     % Real Exports of Goods and Services
IMPGSC1 = readtimetable(fullfile(folder,"IMPGSC1.xls"),"NumHeaderLines",10);     % Real imports of goods and services
DSPIC96 = readtimetable(fullfile(folder,"DSPIC96.xls"),"NumHeaderLines",10);     % Real Disposable Personal Income
INDPRO = readtimetable(fullfile(folder,"INDPRO.xls"),"NumHeaderLines",10);       % Industrial Production: Total Index

% Price data
CPIAUCSL = readtimetable(fullfile(folder,"CPIAUCSL.xls"),"NumHeaderLines",10);   % Consumer Price Index for All Urban Consumers
CPILFESL = readtimetable(fullfile(folder,"CPILFESL.xls"),"NumHeaderLines",10);   % Consumer Price Index for All Urban Consumers: All Items Less Food and Energy
PPIACO = readtimetable(fullfile(folder,"PPIACO.xls"),"NumHeaderLines",10);       % Producer Price Index by Commodity: All Commodities
GDPCTPI = readtimetable(fullfile(folder,"GDPCTPI.xls"),"NumHeaderLines",10);     % Gross Domestic Product: Chain-type Price Index
PCEPI = readtimetable(fullfile(folder,"PCEPI.xls"),"NumHeaderLines",10);         % Personal Consumption Expenditures: Chain-type Price Index

% Employment data
UNRATE = readtimetable(fullfile(folder,"UNRATE.xls"),"NumHeaderLines",10);       % Unemployment Rate
UEMPMEAN = readtimetable(fullfile(folder,"UEMPMEAN.xls"),"NumHeaderLines",10);   % Average Weeks Unemployed
PAYEMS = readtimetable(fullfile(folder,"PAYEMS.xls"),"NumHeaderLines",10);       % All Employees, Total Nonfarm
COMPNFB = readtimetable(fullfile(folder,"COMPNFB.xls"),"NumHeaderLines",10);     % Nonfarm Business Sector: Hourly Compensation for All Workers

% Industry data
MCUMFN = readtimetable(fullfile(folder,"MCUMFN.xls"),"NumHeaderLines",10);       % Capacity Utilization: Manufacturing
HOUST = readtimetable(fullfile(folder,"HOUST.xls"),"NumHeaderLines",10);         % New Privately-Owned Housing Units Started: Total Units
CQRMTSPL = readtimetable(fullfile(folder,"CQRMTSPL.xls"),"NumHeaderLines",10);   % Real Manufacturing and Trade Industries Sales
BUSLOANS = readtimetable(fullfile(folder,"BUSLOANS.xls"),"NumHeaderLines",10);   % Commercial and Industrial Loans
UMCSENT = readtimetable(fullfile(folder,"UMCSENT.xls"),"NumHeaderLines",10);     % University of Michigan: Consumer Sentiment

% Money data
M2SL = readtimetable(fullfile(folder,"M2SL.xls"),"NumHeaderLines",10);           % M2, Billions of Dollars
TOTRESNS = readtimetable(fullfile(folder,"TOTRESNS.xls"),"NumHeaderLines",10);   % Reserves of Depository Institutions: Total

% Interest rate data
FEDFUNDS = readtimetable(fullfile(folder,"FEDFUNDS.xls"),"NumHeaderLines",10);   % Federal Funds Effective Rate
GS1 = readtimetable(fullfile(folder,"GS1.xls"),"NumHeaderLines",10);             % Market Yield on U.S. Treasury Securities at 1-Year Constant Maturity
GS3 = readtimetable(fullfile(folder,"GS3.xls"),"NumHeaderLines",10);             % Market Yield on U.S. Treasury Securities at 3-Year Constant Maturity
GS5 = readtimetable(fullfile(folder,"GS5.xls"),"NumHeaderLines",10);             % Market Yield on U.S. Treasury Securities at 5-Year Constant Maturity
GS7 = readtimetable(fullfile(folder,"GS7.xls"),"NumHeaderLines",10);             % Market Yield on U.S. Treasury Securities at 7-Year Constant Maturity
GS10 = readtimetable(fullfile(folder,"GS10.xls"),"NumHeaderLines",10);           % Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity
GS20 = readtimetable(fullfile(folder,"GS20.xls"),"NumHeaderLines",10);           % Market Yield on U.S. Treasury Securities at 20-Year Constant Maturity
AAA = readtimetable(fullfile(folder,"AAA.xls"),"NumHeaderLines",10);             % Moody's Seasoned Aaa Corporate Bond Yield
BAA = readtimetable(fullfile(folder,"BAA.xls"),"NumHeaderLines",10);             % Moody's Seasoned Baa Corporate Bond Yield

% Financial data
WILL5000IND = readtimetable(fullfile(folder,"WILL5000IND.xls"),"NumHeaderLines",10); % Wilshire 5000 Total Market Index
NASDAQCOM = readtimetable(fullfile(folder,"NASDAQCOM.xls"),"NumHeaderLines",10); % NASDAQ Composite Index
WTISPLC = readtimetable(fullfile(folder,"WTISPLC.xls"),"NumHeaderLines",10);     % Spot Crude Oil Price: West Texas Intermediate
EXUSUK = readtimetable(fullfile(folder,"EXUSUK.xls"),"NumHeaderLines",10);       % U.S. Dollars to U.K. Pound Sterling Spot Exchange Rate
EXJPUS = readtimetable(fullfile(folder,"EXJPUS.xls"),"NumHeaderLines",10);       % Japanese Yen to U.S. Dollar Spot Exchange Rate
EXCAUS = readtimetable(fullfile(folder,"EXCAUS.xls"),"NumHeaderLines",10);       % Canadian Dollars to U.S. Dollar Spot Exchange Rate

% Concatenate data
TimeTable = synchronize(GDPC1,PCECC96,GPDIC1,GCEC1,EXPGSC1,IMPGSC1,DSPIC96,INDPRO,...
    CPIAUCSL,CPILFESL,PPIACO,GDPCTPI,PCEPI,...
    UNRATE,UEMPMEAN,PAYEMS,COMPNFB,...
    MCUMFN,HOUST,CQRMTSPL,BUSLOANS,UMCSENT,...
    M2SL,TOTRESNS,...
    FEDFUNDS,GS1,GS3,GS5,GS7,GS10,GS20,AAA,BAA,...
    WILL5000IND,NASDAQCOM,WTISPLC,EXUSUK,EXJPUS);    
varNames = string(TimeTable.Properties.VariableNames);

% Log transformation of data and rescaling
logVariable = ["GDPC1" "PCECC96" "GPDIC1"  "GCEC1" "EXPGSC1" "IMPGSC1" "DSPIC96" "INDPRO" ...
    "CPIAUCSL" "CPILFESL" "PPIACO" "GDPCTPI" "PCEPI" ...
    "PAYEMS" "COMPNFB" ...
    "HOUST" "CQRMTSPL" "BUSLOANS" ...
    "M2SL" "TOTRESNS"...
    "WILL5000IND" "NASDAQCOM" "WTISPLC" "EXUSUK" "EXJPUS"];
    
TimeTable{:,logVariable} = 100*log(TimeTable{:,logVariable});
TimeTable{:,:} = TimeTable{:,:}/100;

% Estimation windows
estimationWindow = timerange(datetime(1975,1,1),datetime(2023,9,30));
EstimationData = TimeTable(estimationWindow,:);

% Prior specificaton on the BVAR model
numSeries = size(EstimationData,2);
numLags = 4;
PriorMdlRW = bayesvarm(numSeries,numLags,'ModelType',"conjugate",'IncludeTrend',1,...
    'Center',1,'SelfLag',1,'Omega',1e-4*eye(numSeries),'DoF',numSeries+2,'SeriesNames',varNames);
PriorMdlST = bayesvarm(numSeries,numLags,'ModelType',"conjugate",'IncludeTrend',1,...
    'Center',0.5,'SelfLag',1,'Omega',1e-4*eye(numSeries),'DoF',numSeries+2,'SeriesNames',varNames);

% Extract pseudo data from normal-inverse-Wishart prior
MdlNIW = NIW(reshape(PriorMdlRW.Mu,[],numSeries),inv(PriorMdlRW.V),PriorMdlRW.Omega,PriorMdlRW.DoF);
DataStruct = extract(MdlNIW,1);
disp(DataStruct)

% Out-of-sample forecast by simulation smoothing of VAR with data augmentation 
numPeriods = 12;
numObs = size(EstimationData,1) - numLags;
DataNaN = [EstimationData{:,:};NaN(numPeriods,numSeries)];
tic;[CoeffDrawsRW,SigmaDrawsRW,~,YMeanRW,YStdRW] = simsmooth(PriorMdlRW,DataNaN);toc;
tic;[CoeffDrawsST,SigmaDrawsST,~,YMeanST,YStdST] = simsmooth(PriorMdlST,DataNaN);toc;
CoeffMeanRW = reshape(mean(CoeffDrawsRW,2),[],numSeries);
CoeffMeanST = reshape(mean(CoeffDrawsST,2),[],numSeries);
SigmaMeanRW = mean(SigmaDrawsRW,3);
SigmaMeanST = mean(SigmaDrawsST,3);

% Forecast with approximately 90% intervals
dates = [EstimationData.observation_date(numLags+1:end); EstimationData.observation_date(end) + calmonths(3*(1:numPeriods)')];
YMeanTTRW = array2timetable(YMeanRW,'RowTimes',dates,'VariableNames',varNames);
YMeanTTST = array2timetable(YMeanST,'RowTimes',dates,'VariableNames',varNames);
YMeanUBRW = array2timetable(YMeanRW + 1.6.*YStdRW,'RowTimes',dates,'VariableNames',varNames);
YMeanLBRW = array2timetable(YMeanRW - 1.6.*YStdRW,'RowTimes',dates,'VariableNames',varNames);
YMeanUBST = array2timetable(YMeanST + 1.6.*YStdST,'RowTimes',dates,'VariableNames',varNames);
YMeanLBST = array2timetable(YMeanST - 1.6.*YStdST,'RowTimes',dates,'VariableNames',varNames);

% Plot forecast results under AR(1) and random-walk priors
plotnames = ["GDPC1" "PCECC96" "GPDIC1" "CPIAUCSL" "UNRATE" "MCUMFN" "GS20" "M2SL" "WILL5000IND"];
plotnameA = ["GDP" "Consumption" "Investment" "CPI" "Unemployment" "Capacity" "Yield" "M2" "Stock"];
seq = numObs-40 : numObs+numPeriods;
seqB = numObs+1 : numObs+numPeriods;

figure(1)
tiledlayout(3,3)
for m = 1:numel(plotnames)
    nexttile    
    plot(dates(seq),YMeanTTST{seq,plotnames(m)},'-b',dates(seqB),YMeanUBST{seqB,plotnames(m)},'--r',dates(seqB),YMeanLBST{seqB,plotnames(m)},'--r');
    title(plotnameA(m))
end

figure(2)
tiledlayout(3,3)
for m = 1:numel(plotnames)
    nexttile    
    plot(dates(seq),YMeanTTRW{seq,plotnames(m)},'-b',dates(seqB),YMeanUBRW{seqB,plotnames(m)},'--r',dates(seqB),YMeanLBRW{seqB,plotnames(m)},'--r');
    title(plotnameA(m))
end
